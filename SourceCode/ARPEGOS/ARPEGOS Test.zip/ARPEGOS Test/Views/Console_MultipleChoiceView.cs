﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ARPEGOS_Test
{
    class Console_MultipleChoiceView
    {
    }
}
