﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ARPEGOS_Test.Views
{
    public class Console_SingleChoiceView
    {

    }
}
