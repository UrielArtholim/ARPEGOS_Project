﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ARPEGOS_Test.Views
{
    class Console_ValuedGroupView
    {
    }
}
