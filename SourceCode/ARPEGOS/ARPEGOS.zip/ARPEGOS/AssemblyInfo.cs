using Xamarin.Forms;
using Xamarin.Forms.Xaml;

[assembly: XamlCompilation(XamlCompilationOptions.Compile)]
[assembly: ExportFont("OldLondon.ttf", Alias = "OldLondon")]
[assembly: ExportFont("OldLondonAlternate.ttf", Alias = "OldLondonAlternate")]