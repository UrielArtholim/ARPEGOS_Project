﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ARPEGOS.Models
{
    public enum ImageType
    {
        Background = 0,
        Add = 1,
        Remove = 2
    }
}
